<?php
/**
 * @file
 * View template for the class admin view.
 *
 * @param array $data
 * 	Contains the data passed from the controller.
 */
?>

<h1>Class Management</h1>