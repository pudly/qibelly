<?php
/**
 * @file
 * View template for the instructor admin view.
 *
 * @param array $data
 * 	Contains the data passed from the controller.
 */
?>

<h1>Instructor Management</h1>