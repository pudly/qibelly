<?php
/**
 * @file
 * View template for the class admin view.
 *
 * @param array $data
 * 	Contains the data passed from the controller.
 */
?>

<h1>Schedule Management</h1>
<p>Please visit the options page for instructions on how to use this plugin.</p>